var searchData=
[
  ['xmalloc_0',['xmalloc',['../group__check__macros.html#gaf3a2d9d47272edc6c30e95c7e238cdc2',1,'util.h']]]
];
