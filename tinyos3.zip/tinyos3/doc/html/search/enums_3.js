var searchData=
[
  ['sched_5fcause_0',['SCHED_CAUSE',['../group__scheduler.html#gaad787d8d80312ffca3c0f197b3a25fbe',1,'kernel_sched.h']]],
  ['shutdown_5fmode_1',['shutdown_mode',['../group__syscalls.html#ga9eb10a0a72ca3149140272e9344a272b',1,'tinyos.h']]]
];
