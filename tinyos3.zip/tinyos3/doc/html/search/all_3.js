var searchData=
[
  ['bare_5ftest_0',['BARE_TEST',['../group__Testing.html#gadeb59351f026036674baa906f32ccd5c',1,'unit_testing.h']]],
  ['barrier_1',['barrier',['../structbarrier.html',1,'']]],
  ['basic_20building_2',['Basic building',['../md_manhelp.html#autotoc_md9',1,'']]],
  ['bios_2eh_3',['bios.h',['../bios_8h.html',1,'']]],
  ['bios_5fcancel_5ftimer_4',['bios_cancel_timer',['../bios_8h.html#a27768c037d72b51415b836bd93196df2',1,'bios.h']]],
  ['bios_5fclock_5',['bios_clock',['../bios_8h.html#a78addcd72c31fb32d46cc51fe01a86b4',1,'bios.h']]],
  ['bios_5fread_5fserial_6',['bios_read_serial',['../bios_8h.html#a04ebe8b1d424c0ef473db751f7b79fbb',1,'bios.h']]],
  ['bios_5fserial_5finterrupt_5fcore_7',['bios_serial_interrupt_core',['../bios_8h.html#a3d9df4f1db5a1d99720f327668726e2b',1,'bios.h']]],
  ['bios_5fserial_5fports_8',['bios_serial_ports',['../bios_8h.html#af69405820033d3f2e8033af258f47ea2',1,'bios.h']]],
  ['bios_5fset_5ftimer_9',['bios_set_timer',['../bios_8h.html#a01f7a35679bdda42fff3da6ae6e5664b',1,'bios.h']]],
  ['bios_5fwrite_5fserial_10',['bios_write_serial',['../bios_8h.html#a97bde2ebd5f9d86c0085aacaa5e5d287',1,'bios.h']]],
  ['bites_11',['bites',['../structsymposium__t.html#a9ee1b978200b8a4b7c30b170c1f20643',1,'symposium_t']]],
  ['boot_12',['boot',['../group__syscalls.html#ga31d9ee7df9665928617a9f9c0cc6d361',1,'boot(uint ncores, uint nterm, Task boot_task, int argl, void *args):&#160;kernel_init.c'],['../group__syscalls.html#ga31d9ee7df9665928617a9f9c0cc6d361',1,'boot(unsigned int ncores, unsigned int terminals, Task boot_task, int argl, void *args):&#160;kernel_init.c']]],
  ['boot_20tests_13',['Boot tests',['../group__Testing.html#autotoc_md23',1,'']]],
  ['boot_5ftest_14',['BOOT_TEST',['../group__Testing.html#gadaaab439c094503b6ed7c313ad082f10',1,'unit_testing.h']]],
  ['bootfunc_15',['bootfunc',['../structvm__config.html#a9eb4f640012b1bcf02ae982e551b5767',1,'vm_config']]],
  ['build_20dependencies_16',['Build dependencies',['../index.html#autotoc_md18',1,'']]],
  ['building_17',['Basic building',['../md_manhelp.html#autotoc_md9',1,'']]],
  ['building_20the_20documentation_18',['Building the documentation',['../md_manhelp.html#autotoc_md15',1,'']]],
  ['building_20tinyos_20using_20make_19',['Building tinyos using make',['../md_manhelp.html#autotoc_md8',1,'']]],
  ['building_20with_20full_20optimizations_20on_20',['Building with full optimizations on',['../md_manhelp.html#autotoc_md11',1,'']]]
];
