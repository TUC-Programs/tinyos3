var searchData=
[
  ['last_5fcause_0',['last_cause',['../structthread__control__block.html#a05cd1b71563678b88b656fd10b8ee78a',1,'thread_control_block']]],
  ['list_5fptcb_1',['list_ptcb',['../structprocess__control__block.html#a14d2652444cf7848e0ba57263c1b6c73',1,'process_control_block']]]
];
