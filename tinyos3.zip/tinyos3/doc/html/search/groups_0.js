var searchData=
[
  ['calls_0',['calls',['../group__check__macros.html',1,'Macros for checking system calls.'],['../group__syscalls.html',1,'System calls.']]],
  ['checking_20system_20calls_1',['Macros for checking system calls.',['../group__check__macros.html',1,'']]],
  ['concurrency_20control_2',['Concurrency control.',['../group__cc.html',1,'']]],
  ['control_3',['Concurrency control.',['../group__cc.html',1,'']]]
];
