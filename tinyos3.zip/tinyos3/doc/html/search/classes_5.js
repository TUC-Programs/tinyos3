var searchData=
[
  ['logrec_0',['logrec',['../structlogrec.html',1,'']]]
];
