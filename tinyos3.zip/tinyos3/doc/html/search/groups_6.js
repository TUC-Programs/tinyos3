var searchData=
[
  ['resource_20lists_0',['Resource lists',['../group__rlists.html',1,'']]]
];
