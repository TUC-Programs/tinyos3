var searchData=
[
  ['pipe_5fs_0',['pipe_s',['../structpipe__s.html',1,'']]],
  ['process_5fcontrol_5fblock_1',['process_control_block',['../structprocess__control__block.html',1,'']]],
  ['process_5fthread_5fcontrol_5fblock_2',['process_thread_control_block',['../structprocess__thread__control__block.html',1,'']]],
  ['procinfo_3',['procinfo',['../structprocinfo.html',1,'']]],
  ['program_5farguments_4',['program_arguments',['../structprogram__arguments.html',1,'']]]
];
