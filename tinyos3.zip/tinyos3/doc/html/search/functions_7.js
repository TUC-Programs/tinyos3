var searchData=
[
  ['initialize_5fdevices_0',['initialize_devices',['../group__dev.html#ga840b5c2460abea4a19a201f7d6d035c8',1,'initialize_devices():&#160;kernel_dev.c'],['../group__dev.html#ga840b5c2460abea4a19a201f7d6d035c8',1,'initialize_devices():&#160;kernel_dev.c']]],
  ['initialize_5ffiles_1',['initialize_files',['../group__streams.html#ga147537248d983b0cc6cc7e8b39245f09',1,'initialize_files():&#160;kernel_streams.c'],['../group__streams.html#ga147537248d983b0cc6cc7e8b39245f09',1,'initialize_files():&#160;kernel_streams.c']]],
  ['initialize_5fprocesses_2',['initialize_processes',['../group__proc.html#ga82948cbeb57bb0b6e15d1f14f06a2db3',1,'initialize_processes():&#160;kernel_proc.c'],['../group__proc.html#ga82948cbeb57bb0b6e15d1f14f06a2db3',1,'initialize_processes():&#160;kernel_proc.c']]],
  ['initialize_5fscheduler_3',['initialize_scheduler',['../group__scheduler.html#ga244fb594301322e79d11a7844c759bba',1,'initialize_scheduler():&#160;kernel_sched.c'],['../group__scheduler.html#ga244fb594301322e79d11a7844c759bba',1,'initialize_scheduler(void):&#160;kernel_sched.c']]],
  ['is_5frlist_5fempty_4',['is_rlist_empty',['../group__rlists.html#gaf60549214daf0df46bcd1a0d5ba5b661',1,'util.h']]],
  ['isdebuggerattached_5',['isDebuggerAttached',['../group__Testing.html#ga106e4293a3520dae79707bdf492dc68b',1,'unit_testing.h']]]
];
