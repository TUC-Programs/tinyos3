var searchData=
[
  ['get_5ffcb_0',['get_fcb',['../group__streams.html#gab653c475f793598f10c15d4e2dd900da',1,'get_fcb(Fid_t fid):&#160;kernel_streams.c'],['../group__streams.html#gab653c475f793598f10c15d4e2dd900da',1,'get_fcb(Fid_t fid):&#160;kernel_streams.c']]],
  ['get_5fpcb_1',['get_pcb',['../group__proc.html#ga3923912bfa906265d441e6212e5e22b4',1,'get_pcb(Pid_t pid):&#160;kernel_proc.c'],['../group__proc.html#ga3923912bfa906265d441e6212e5e22b4',1,'get_pcb(Pid_t pid):&#160;kernel_proc.c']]],
  ['get_5fpid_2',['get_pid',['../group__proc.html#ga110e884cb053244b18d1058751a78cfe',1,'get_pid(PCB *pcb):&#160;kernel_proc.c'],['../group__proc.html#ga110e884cb053244b18d1058751a78cfe',1,'get_pid(PCB *pcb):&#160;kernel_proc.c']]],
  ['getpid_3',['GetPid',['../group__syscalls.html#ga5106ac1f078c5dde2d6fea3881c1a4fb',1,'tinyos.h']]],
  ['getppid_4',['GetPPid',['../group__syscalls.html#ga33ccb3f7c80d85e610206c0e1150657b',1,'tinyos.h']]],
  ['getterminaldevices_5',['GetTerminalDevices',['../group__syscalls.html#ga31576e1579c15b6b066038702e6557c7',1,'tinyos.h']]]
];
